"""
XGE - X Graphics Engine
Простой и оптимизированный графический движок
"""

from .xge import *

__version__ = "0.0.1"
__author__ = "XGE Developer"
__license__ = "MIT"