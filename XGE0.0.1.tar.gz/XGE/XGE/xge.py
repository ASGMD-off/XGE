import pygame
import time
from typing import Dict, List, Tuple, Optional

# Глобальный экземпляр движка
_xge_instance = None

class Shape:
    def __init__(self, name, shape_type, points, color, **kwargs):
        self.name = name
        self.type = shape_type
        self.points = points
        self.color = color
        self.visible = kwargs.get('visible', True)
        self.radius = kwargs.get('radius')
        self.text = kwargs.get('text')
        self.font_size = kwargs.get('font_size')
        self.width = kwargs.get('width')
        self.height = kwargs.get('height')
        self.filled = kwargs.get('filled', False)
        self.thickness = kwargs.get('thickness', 2)

class XGE:
    def __init__(self, width: int = 800, height: int = 600, title: str = "XGE Engine"):
        pygame.init()
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.shapes: Dict[str, Shape] = {}
        self.current_color = (255, 0, 0)
        self.running = True
        self.delta_time = 0
        self.last_time = time.time()
        
    def SetColor(self, hex_color: str) -> None:
        hex_color = hex_color.lstrip('#')
        if len(hex_color) == 6:
            self.current_color = (
                int(hex_color[0:2], 16),
                int(hex_color[2:4], 16),
                int(hex_color[4:6], 16)
            )
        elif len(hex_color) == 3:
            self.current_color = (
                int(hex_color[0]*2, 16),
                int(hex_color[1]*2, 16),
                int(hex_color[2]*2, 16)
            )
    
    def DrawPoint(self, name: str, x: int, y: int, size: int = 2) -> None:
        self.shapes[name] = Shape(name, "point", [(x, y)], self.current_color, radius=size)
    
    def DrawLine(self, name: str, x1: int, y1: int, x2: int, y2: int, thickness: int = 2) -> None:
        self.shapes[name] = Shape(name, "line", [(x1, y1), (x2, y2)], self.current_color, thickness=thickness)
    
    def DrawRect(self, name: str, x: int, y: int, width: int, height: int, filled: bool = False) -> None:
        self.shapes[name] = Shape(name, "rect", [(x, y)], self.current_color, width=width, height=height, filled=filled)
    
    def DrawCircle(self, name: str, center_x: int, center_y: int, radius: int, filled: bool = False) -> None:
        self.shapes[name] = Shape(name, "circle", [(center_x, center_y)], self.current_color, radius=radius, filled=filled)
    
    def DrawTriangle(self, name: str, x1: int, y1: int, x2: int, y2: int, x3: int, y3: int, filled: bool = False) -> None:
        self.shapes[name] = Shape(name, "triangle", [(x1, y1), (x2, y2), (x3, y3)], self.current_color, filled=filled)
    
    def DrawText(self, name: str, text: str, x: int, y: int, font_size: int = 24) -> None:
        self.shapes[name] = Shape(name, "text", [(x, y)], self.current_color, text=text, font_size=font_size)
    
    def UnDraw(self, name: str) -> None:
        if name in self.shapes:
            del self.shapes[name]
    
    def Hide(self, name: str) -> None:
        if name in self.shapes:
            self.shapes[name].visible = False
    
    def Show(self, name: str) -> None:
        if name in self.shapes:
            self.shapes[name].visible = True
    
    def Clear(self) -> None:
        self.shapes.clear()
    
    def GetMousePos(self) -> Tuple[int, int]:
        return pygame.mouse.get_pos()
    
    def IsKeyPressed(self, key: str) -> bool:
        return pygame.key.get_pressed()[getattr(pygame, f"K_{key.upper()}", 0)]
    
    def render(self) -> None:
        self.screen.fill((0, 0, 0))
        
        for shape in self.shapes.values():
            if not shape.visible:
                continue
                
            if shape.type == "point":
                pygame.draw.circle(self.screen, shape.color, shape.points[0], shape.radius or 2)
            
            elif shape.type == "line":
                pygame.draw.line(self.screen, shape.color, shape.points[0], shape.points[1], shape.thickness)
            
            elif shape.type == "rect":
                rect = pygame.Rect(shape.points[0][0], shape.points[0][1], shape.width, shape.height)
                if shape.filled:
                    pygame.draw.rect(self.screen, shape.color, rect)
                else:
                    pygame.draw.rect(self.screen, shape.color, rect, 2)
            
            elif shape.type == "circle":
                if shape.filled:
                    pygame.draw.circle(self.screen, shape.color, shape.points[0], shape.radius)
                else:
                    pygame.draw.circle(self.screen, shape.color, shape.points[0], shape.radius, 2)
            
            elif shape.type == "triangle":
                if shape.filled:
                    pygame.draw.polygon(self.screen, shape.color, shape.points)
                else:
                    pygame.draw.polygon(self.screen, shape.color, shape.points, 2)
            
            elif shape.type == "text":
                font = pygame.font.Font(None, shape.font_size or 24)
                text_surface = font.render(shape.text, True, shape.color)
                self.screen.blit(text_surface, shape.points[0])
        
        pygame.display.flip()
    
    def handle_events(self) -> bool:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
        return self.running
    
    def run(self, fps: int = 60) -> None:
        while self.handle_events():
            current_time = time.time()
            self.delta_time = current_time - self.last_time
            self.last_time = current_time
            
            self.render()
            self.clock.tick(fps)
        
        pygame.quit()

# Цвета
class Colors:
    RED = "#FF0000"
    GREEN = "#00FF00"
    BLUE = "#0000FF"
    YELLOW = "#FFFF00"
    CYAN = "#00FFFF"
    MAGENTA = "#FF00FF"
    WHITE = "#FFFFFF"
    BLACK = "#000000"
    GRAY = "#808080"

# Глобальные функции
def init(width=800, height=600, title="XGE Engine"):
    global _xge_instance
    _xge_instance = XGE(width, height, title)
    return _xge_instance

def get_instance():
    global _xge_instance
    if _xge_instance is None:
        _xge_instance = XGE()
    return _xge_instance

def set_color(hex_color):
    return get_instance().SetColor(hex_color)

def draw_point(name, x, y, size=2):
    return get_instance().DrawPoint(name, x, y, size)

def draw_line(name, x1, y1, x2, y2, thickness=2):
    return get_instance().DrawLine(name, x1, y1, x2, y2, thickness)

def draw_rect(name, x, y, width, height, filled=False):
    return get_instance().DrawRect(name, x, y, width, height, filled)

def draw_circle(name, center_x, center_y, radius, filled=False):
    return get_instance().DrawCircle(name, center_x, center_y, radius, filled)

def draw_triangle(name, x1, y1, x2, y2, x3, y3, filled=False):
    return get_instance().DrawTriangle(name, x1, y1, x2, y2, x3, y3, filled)

def draw_text(name, text, x, y, font_size=24):
    return get_instance().DrawText(name, text, x, y, font_size)

def undraw(name):
    return get_instance().UnDraw(name)

def hide(name):
    return get_instance().Hide(name)

def show(name):
    return get_instance().Show(name)

def clear():
    return get_instance().Clear()

def run(fps=60):
    return get_instance().run(fps)

# Псевдонимы
Point = draw_point
Line = draw_line
Rect = draw_rect
Circle = draw_circle
Triangle = draw_triangle
Text = draw_text
Color = set_color